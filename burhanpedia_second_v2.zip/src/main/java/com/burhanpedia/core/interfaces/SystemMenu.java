package com.burhanpedia.core.interfaces;

public interface SystemMenu {
    String showMenu();
    void handleMenu();
}