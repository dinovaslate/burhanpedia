package com.burhanpedia.model.user;

public class Pengirim extends User {
    public Pengirim(String username, String password) {
        super(username, password, "Pengirim");
    }
}