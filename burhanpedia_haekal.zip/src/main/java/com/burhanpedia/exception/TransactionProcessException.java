package com.burhanpedia.exception;
 
public class TransactionProcessException extends Exception {
    public TransactionProcessException(String message) {
        super(message);
    }
} 